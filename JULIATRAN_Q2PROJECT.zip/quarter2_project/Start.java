import java.io.File;
import java.io.FileNotFoundException;
/**
 * This is the starter class.
 *
 * @author (Julia Tran)
 * @version (12/4/21)
 */
public class Start 
{
   public static void main (String []args)throws FileNotFoundException
   {
       new GUI();
    }
}